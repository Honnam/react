# @babel/plugin-transform-typescript

> Transform TypeScript into ES.next

See our website [@babel/plugin-transform-typescript](https://babeljs.io/docs/en/babel-plugin-transform-typescript) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-typescript
```

or using yarn:

```sh
yarn add @babel/plugin-transform-typescript --dev
```
